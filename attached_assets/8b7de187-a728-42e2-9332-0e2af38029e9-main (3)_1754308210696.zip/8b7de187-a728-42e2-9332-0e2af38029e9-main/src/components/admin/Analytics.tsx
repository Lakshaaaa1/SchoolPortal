
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { supabase } from "@/integrations/supabase/client";
import { Users, DollarSign, BookOpen, TrendingUp, GraduationCap, Calendar } from 'lucide-react';

export function Analytics() {
  const [stats, setStats] = useState({
    totalStudents: 0,
    totalTeachers: 0,
    totalRevenue: 0,
    pendingFees: 0,
    classStats: [] as any[],
    feeStats: [] as any[],
    recentPayments: [] as any[]
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      
      // Total students
      const { count: studentCount } = await supabase
        .from('students')
        .select('*', { count: 'exact', head: true });

      // Total teachers
      const { count: teacherCount } = await supabase
        .from('teachers')
        .select('*', { count: 'exact', head: true });

      // Fee payments statistics
      const { data: feePayments } = await supabase
        .from('fee_payments')
        .select('amount_paid, amount_pending, payment_date, students(class)');

      // Convert to numbers and calculate totals
      const totalRevenue = feePayments?.reduce((sum, payment) => {
        const amount = Number(payment.amount_paid) || 0;
        return sum + amount;
      }, 0) || 0;

      const pendingFees = feePayments?.reduce((sum, payment) => {
        const amount = Number(payment.amount_pending) || 0;
        return sum + amount;
      }, 0) || 0;

      // Recent payments (last 5)
      const { data: recentPayments } = await supabase
        .from('fee_payments')
        .select(`
          amount_paid,
          payment_date,
          payment_mode,
          students(full_name, name, class, section)
        `)
        .order('payment_date', { ascending: false })
        .limit(5);

      // Class-wise student count
      const { data: classData } = await supabase
        .from('students')
        .select('class, section');

      const classStats = classData?.reduce((acc: any, student) => {
        const key = student.section ? `${student.class} ${student.section}` : student.class;
        acc[key] = (acc[key] || 0) + 1;
        return acc;
      }, {});

      const classStatsArray = Object.entries(classStats || {})
        .map(([className, count]) => ({ class: className, count: Number(count) }))
        .sort((a, b) => Number(b.count) - Number(a.count));

      // Fee collection by class
      const feeStats = feePayments?.reduce((acc: any, payment) => {
        const className = payment.students?.class || 'Unknown';
        if (!acc[className]) {
          acc[className] = { class: className, collected: 0, pending: 0 };
        }
        const paidAmount = Number(payment.amount_paid) || 0;
        const pendingAmount = Number(payment.amount_pending) || 0;
        acc[className].collected += paidAmount;
        acc[className].pending += pendingAmount;
        return acc;
      }, {});

      const feeStatsArray = Object.values(feeStats || {}).sort((a: any, b: any) => b.collected - a.collected);

      setStats({
        totalStudents: studentCount || 0,
        totalTeachers: teacherCount || 0,
        totalRevenue,
        pendingFees,
        classStats: classStatsArray,
        feeStats: feeStatsArray,
        recentPayments: recentPayments || []
      });
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-24 bg-muted animate-pulse rounded-lg" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <GraduationCap className="h-4 w-4" />
                Total Students
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{stats.totalStudents}</div>
              <p className="text-xs text-muted-foreground">Active enrollments</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Users className="h-4 w-4" />
                Total Teachers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.totalTeachers}</div>
              <p className="text-xs text-muted-foreground">Teaching staff</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <DollarSign className="h-4 w-4" />
                Total Revenue
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">₹{stats.totalRevenue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Fees collected</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Pending Fees
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">₹{stats.pendingFees.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Outstanding amount</p>
            </CardContent>
          </Card>
        </div>

        {/* Class-wise Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Class-wise Student Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {stats.classStats.slice(0, 10).map((item) => (
                <div key={item.class} className="flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <span className="font-medium min-w-0">{item.class}</span>
                    <Progress 
                      value={(item.count / stats.totalStudents) * 100} 
                      className="flex-1 h-2"
                    />
                  </div>
                  <span className="text-sm font-medium ml-2">{item.count} students</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Fee Collection by Class */}
        {stats.feeStats.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Fee Collection by Class
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {stats.feeStats.slice(0, 8).map((item: any) => (
                  <div key={item.class} className="p-3 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">{item.class}</span>
                      <span className="text-sm text-muted-foreground">
                        Collected: ₹{item.collected.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-green-600">
                        ₹{item.collected.toLocaleString()} collected
                      </span>
                      <span className="text-red-600">
                        ₹{item.pending.toLocaleString()} pending
                      </span>
                    </div>
                    <Progress 
                      value={(item.collected / (item.collected + item.pending)) * 100} 
                      className="mt-2 h-2"
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent Payments */}
        {stats.recentPayments.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Recent Fee Payments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {stats.recentPayments.map((payment, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">
                        {payment.students?.full_name || payment.students?.name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {payment.students?.class} {payment.students?.section} • {payment.payment_mode}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-green-600">₹{Number(payment.amount_paid).toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(payment.payment_date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Summary Card */}
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-800">School Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-blue-600 font-medium">Academic Strength</p>
                <p className="text-blue-800">
                  {stats.totalStudents} students across {stats.classStats.length} classes
                </p>
              </div>
              <div>
                <p className="text-blue-600 font-medium">Financial Health</p>
                <p className="text-blue-800">
                  {stats.totalRevenue > 0 && stats.pendingFees > 0 
                    ? `${Math.round((stats.totalRevenue / (stats.totalRevenue + stats.pendingFees)) * 100)}% collection rate`
                    : 'Fee collection in progress'
                  }
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
    </div>
  );
}
