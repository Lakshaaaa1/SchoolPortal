import React from 'react';
import { SetFeeTerms } from './SetFeeTerms';

export function SetFeeStructureSection() {
  return <SetFeeTerms />;
}