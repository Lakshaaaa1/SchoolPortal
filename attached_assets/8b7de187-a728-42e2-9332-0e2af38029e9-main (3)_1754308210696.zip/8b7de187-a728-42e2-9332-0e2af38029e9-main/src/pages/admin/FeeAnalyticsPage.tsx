
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, DollarSign, Users, AlertTriangle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface StudentFeeData {
  id: string;
  name: string;
  rollNo: number;
  totalFee: number;
  amountPaid: number;
  pendingAmount: number;
  status: 'Paid' | 'Partially Paid' | 'Unpaid';
}

const FeeAnalyticsPage = () => {
  const [classes, setClasses] = useState<string[]>([]);
  const [sections, setSections] = useState<string[]>([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedSection, setSelectedSection] = useState('');
  const [students, setStudents] = useState<StudentFeeData[]>([]);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const { toast } = useToast();

  useEffect(() => {
    fetchClasses();
  }, []);

  useEffect(() => {
    if (selectedClass) {
      fetchSections();
    }
  }, [selectedClass]);

  useEffect(() => {
    if (selectedClass && selectedSection) {
      fetchFeeAnalytics();
    }
  }, [selectedClass, selectedSection]);

  const fetchClasses = async () => {
    const { data, error } = await supabase
      .from('students')
      .select('class')
      .not('class', 'is', null);
    
    if (error) {
      toast({
        title: "Error",
        description: "Failed to fetch classes",
        variant: "destructive",
      });
      return;
    }

    const uniqueClasses = [...new Set(data.map(item => item.class))];
    setClasses(uniqueClasses);
  };

  const fetchSections = async () => {
    const { data, error } = await supabase
      .from('students')
      .select('section')
      .eq('class', selectedClass)
      .not('section', 'is', null);
    
    if (error) {
      toast({
        title: "Error",
        description: "Failed to fetch sections",
        variant: "destructive",
      });
      return;
    }

    const uniqueSections = [...new Set(data.map(item => item.section))];
    setSections(uniqueSections);
  };

  const fetchFeeAnalytics = async () => {
    setLoading(true);
    
    try {
      // Fetch students
      const { data: studentsData, error: studentsError } = await supabase
        .from('students')
        .select('*')
        .eq('class', selectedClass)
        .eq('section', selectedSection);

      if (studentsError) throw studentsError;

      // Fetch fee structure for the class
      const { data: feeStructure, error: feeError } = await supabase
        .from('fee_structures')
        .select('*')
        .eq('class', selectedClass);

      if (feeError) throw feeError;

      // Calculate total fee for the class
      const totalClassFee = feeStructure?.reduce((sum, fee) => sum + Number(fee.amount), 0) || 0;

      // Fetch fee payments
      const { data: feePayments, error: paymentsError } = await supabase
        .from('fee_payments')
        .select('*');

      if (paymentsError) throw paymentsError;

      // Process student fee data
      const processedStudents: StudentFeeData[] = studentsData?.map((student, index) => {
        const studentPayments = feePayments?.filter(payment => payment.student_id === student.id) || [];
        const amountPaid = studentPayments.reduce((sum, payment) => sum + Number(payment.amount_paid), 0);
        const pendingAmount = totalClassFee - amountPaid;
        
        let status: 'Paid' | 'Partially Paid' | 'Unpaid';
        if (pendingAmount <= 0) {
          status = 'Paid';
        } else if (amountPaid > 0) {
          status = 'Partially Paid';
        } else {
          status = 'Unpaid';
        }

        return {
          id: student.id,
          name: student.full_name || student.name || 'Unknown',
          rollNo: index + 1,
          totalFee: totalClassFee,
          amountPaid,
          pendingAmount: Math.max(0, pendingAmount),
          status
        };
      }) || [];

      setStudents(processedStudents);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch fee analytics",
        variant: "destructive",
      });
    }
    
    setLoading(false);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Paid':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">🟢 Paid</Badge>;
      case 'Partially Paid':
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">🟡 Partially Paid</Badge>;
      case 'Unpaid':
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">🔴 Unpaid</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const filteredStudents = students.filter(student => {
    if (statusFilter === 'all') return true;
    return student.status === statusFilter;
  });

  const stats = {
    total: students.length,
    paid: students.filter(s => s.status === 'Paid').length,
    partial: students.filter(s => s.status === 'Partially Paid').length,
    unpaid: students.filter(s => s.status === 'Unpaid').length,
  };

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" asChild>
            <Link to="/dashboard/admin">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Fee Analytics</h1>
            <p className="text-muted-foreground">Track student fee payments and outstanding amounts</p>
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Class</label>
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes.map((cls) => (
                      <SelectItem key={cls} value={cls}>{cls}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Section</label>
                <Select value={selectedSection} onValueChange={setSelectedSection} disabled={!selectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select section" />
                  </SelectTrigger>
                  <SelectContent>
                    {sections.map((section) => (
                      <SelectItem key={section} value={section}>{section}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Status Filter</label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="Paid">Paid Only</SelectItem>
                    <SelectItem value="Partially Paid">Partially Paid</SelectItem>
                    <SelectItem value="Unpaid">Unpaid Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        {selectedClass && selectedSection && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Students</p>
                    <p className="text-2xl font-bold">{stats.total}</p>
                  </div>
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Paid</p>
                    <p className="text-2xl font-bold text-green-600">{stats.paid}</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Partial</p>
                    <p className="text-2xl font-bold text-yellow-600">{stats.partial}</p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Unpaid</p>
                    <p className="text-2xl font-bold text-red-600">{stats.unpaid}</p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-red-600" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Student Fee Table */}
        {selectedClass && selectedSection && (
          <Card>
            <CardHeader>
              <CardTitle>Fee Status - {selectedClass} {selectedSection}</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">Loading...</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Roll No.</TableHead>
                      <TableHead>Student Name</TableHead>
                      <TableHead>Total Fee</TableHead>
                      <TableHead>Amount Paid</TableHead>
                      <TableHead>Pending Amount</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredStudents.map((student) => (
                      <TableRow key={student.id}>
                        <TableCell>{student.rollNo.toString().padStart(2, '0')}</TableCell>
                        <TableCell className="font-medium">{student.name}</TableCell>
                        <TableCell>₹{student.totalFee.toLocaleString()}</TableCell>
                        <TableCell>₹{student.amountPaid.toLocaleString()}</TableCell>
                        <TableCell>₹{student.pendingAmount.toLocaleString()}</TableCell>
                        <TableCell>{getStatusBadge(student.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default FeeAnalyticsPage;
