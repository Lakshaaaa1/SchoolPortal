
package com.example.schoolportal;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.BridgeActivity;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends BridgeActivity {
	private static final int REQUEST_CODE_POST_NOTIFICATIONS = 1001;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Initialize Firebase if not already initialized
		if (FirebaseApp.getApps(this).isEmpty()) {
			FirebaseApp.initializeApp(this);
		}
		// Request notification permission on Android 13+
		if (Build.VERSION.SDK_INT >= 33) {
			if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
				ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_CODE_POST_NOTIFICATIONS);
			} else {
				registerForPushNotifications();
			}
		} else {
			registerForPushNotifications();
		}
	}

	private void registerForPushNotifications() {
		// Register for FCM token and handle result
		FirebaseMessaging.getInstance().getToken()
			.addOnCompleteListener(task -> {
				if (task.isSuccessful()) {
					String token = task.getResult();
					// Optionally log or send token to your server
				} else {
					// Optionally log error
				}
			});
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == REQUEST_CODE_POST_NOTIFICATIONS) {
			if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
				registerForPushNotifications();
			}
		}
	}
}
