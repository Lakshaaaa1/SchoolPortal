import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import NotFound from "@/pages/not-found";
import { useEffect } from "react";
import { messaging } from "@/lib/firebase";
import { getToken, onMessage } from "firebase/messaging";

function useFCM() {
  useEffect(() => {
    if ('Notification' in window && navigator.serviceWorker) {
      Notification.requestPermission().then((permission) => {
        if (permission === "granted") {
          navigator.serviceWorker.register("/firebase-messaging-sw.js")
            .then(() => {
              getToken(messaging, { vapidKey: "BNrpS07B2smp2d5DF7VOc_3WZ4AJdwjAdC6Kkiosc79Z_xZsEdWI61CRwPGW59OBz0j2MNLroxX4FzpqEKlebDc" })
                .then((currentToken) => {
                  if (currentToken) {
                    // Get student info from auth context or localStorage
                    let studentId = localStorage.getItem('student_id');
                    let studentClass = localStorage.getItem('student_class');
                    let studentSection = localStorage.getItem('student_section');
                    try {
                      // Try to get from auth context if available
                      const auth = require('@/hooks/use-auth');
                      if (auth && auth.useAuth) {
                        const { student } = auth.useAuth();
                        if (student) {
                          studentId = student.id || studentId;
                          studentClass = student.class || studentClass;
                          studentSection = student.section || studentSection;
                        }
                      }
                    } catch {}
                    fetch('/api/save-fcm-token', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        token: currentToken,
                        studentId,
                        class: studentClass,
                        section: studentSection
                      }),
                    })
                      .then(res => res.ok ? res.json() : Promise.reject(res))
                      .then(data => {
                        console.log('FCM token saved to backend:', data);
                      })
                      .catch(err => {
                        console.error('Failed to save FCM token:', err);
                      });
                  }
                });
            });
        }
      });

      onMessage(messaging, (payload) => {
        // Show notification in foreground
        if (payload.notification) {
          new Notification(payload.notification.title || 'Notification', {
            body: payload.notification.body,
            icon: '/icon-192x192.png'
          });
        }
      });
    }
  }, []);
}
function AppContent() {
  const { student } = useAuth();

  if (!student) {
    return <Login />;
  }

  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}


function App() {
  useFCM();
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <div style={{ paddingTop: 24, boxSizing: 'border-box', minHeight: '100vh' }}>
            <Toaster />
            <AppContent />
          </div>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
