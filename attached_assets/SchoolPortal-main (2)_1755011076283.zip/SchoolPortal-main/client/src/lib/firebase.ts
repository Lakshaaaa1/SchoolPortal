import { initializeApp } from "firebase/app";
import { getMessaging } from "firebase/messaging";

const firebaseConfig = {
  apiKey: "AIzaSyB0vftodMWtkvS42wp3C0Xrk0NDoSilxKQ",
    authDomain: "studentapp-4b375.firebaseapp.com",
      projectId: "studentapp-4b375",
        storageBucket: "studentapp-4b375.appspot.com",
          messagingSenderId: "683202022613",
            appId: "1:683202022613:android:099a1f9871777b616e265c",
            };

            const app = initializeApp(firebaseConfig);
            export const messaging = getMessaging(app);
            