
import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { createClient } from '@supabase/supabase-js';
import admin from 'firebase-admin';
import path from 'path';


// --- Supabase client setup ---
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

// --- Firebase Admin SDK setup ---
const serviceAccountPath = process.env.FIREBASE_ADMIN_SDK_JSON || path.join(__dirname, '../firebase-adminsdk.json');
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccountPath),
  });
}

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
(async () => {
  // --- API: Save FCM token ---
  app.post('/api/save-fcm-token', async (req: Request, res: Response) => {
    const { token, studentId } = req.body;
    if (!token || !studentId) {
      return res.status(400).json({ error: 'Missing token or studentId' });
    }
    // Upsert token for student
    const { error } = await supabase
      .from('fcm_tokens')
      .insert({ student_id: studentId, token });
    if (error) {
      return res.status(500).json({ error: error.message });
    }
    return res.json({ success: true });
  });

  // --- API: Add announcement and send FCM notification ---
  app.post('/api/add-announcement', async (req: Request, res: Response) => {
    const { title, message, description, target_class, target_section } = req.body;
    if (!title || !message) {
      return res.status(400).json({ error: 'Missing title or message' });
    }
    // Insert announcement into Supabase
    const { data: announcement, error: insertError } = await supabase
      .from('announcements')
      .insert([{ title, message, description, target_class, target_section }])
      .select()
      .single();
    if (insertError) {
      return res.status(500).json({ error: insertError.message });
    }
    // Get all FCM tokens (optionally filter by class/section)
    let tokensQuery = supabase.from('fcm_tokens').select('token');
    if (target_class) tokensQuery = tokensQuery.eq('class', target_class);
    if (target_section) tokensQuery = tokensQuery.eq('section', target_section);
    const { data: tokensData, error: tokensError } = await tokensQuery;
    if (tokensError) {
      return res.status(500).json({ error: tokensError.message });
    }
    const tokens = (tokensData || []).map((row: any) => row.token).filter(Boolean);
    if (tokens.length === 0) {
      return res.json({ announcement, notification: 'No tokens to notify' });
    }
    // Send FCM notification
    const payload = {
      notification: {
        title,
        body: message,
      },
      data: {
        type: 'announcement',
        announcementId: announcement.id?.toString() || '',
      },
    };
    try {
  // Use sendEachForMulticast for sending to multiple tokens (firebase-admin v13+)
  const multicastResponse = await admin.messaging().sendEachForMulticast({ tokens, ...payload });
      // Log sent notification
      await supabase.from('notifications').insert([
        {
          announcement_id: announcement.id,
          title,
          body: message,
          target_class,
          target_section
        }
      ]);
      return res.json({ announcement, notification: multicastResponse });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }
 
      log(logLine);
    }
  });


  next();
  });

  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
